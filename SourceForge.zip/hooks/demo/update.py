# Example update hook
def update(ref, old_sha, new_sha):
    # allow everything (placeholder)
    return True, "ok"
