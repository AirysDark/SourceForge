
# SourceForge Alpha Full Stack

Start everything:

docker compose up --build -d

Then open:

http://<your-pi-ip>/

Backend health:

http://<your-pi-ip>/api/health
